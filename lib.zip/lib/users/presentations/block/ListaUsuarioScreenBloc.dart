import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'usuario_event_state.dart';

class Usuario {
  final String imagenAsset;
  final String nombre;
  final String correo;
  final String telefono;

  Usuario({
    required this.imagenAsset,
    required this.nombre,
    required this.correo,
    required this.telefono,
  });
}

class ListaUsuarioBloc extends Bloc<UsuarioEvent, UsuarioState> {
  ListaUsuarioBloc() : super(UsuarioInitial());

  @override
  Stream<UsuarioState> mapEventToState(UsuarioEvent event) async* {
    if (event is ObtenerUsuarios) {
      yield UsuarioLoading();
      try {
        final url = Uri.parse('http://127.0.0.1:5000/usuarios/${event.orden}');

        final response = await http.get(url);

        if (response.statusCode == 200) {
          final List<dynamic> data = json.decode(response.body);

          final usuarios = data.map((usuario) {
            return Usuario(
              imagenAsset: 'assets/images/perfil.jpg',
              nombre: usuario['nombre'],
              correo: usuario['email'],
              telefono: usuario['telefono'],
            );
          }).toList();

          yield UsuarioLoaded(usuarios);
        } else {
          yield UsuarioError();
        }
      } catch (_) {
        yield UsuarioError();
      }
    }
  }
}
