import 'package:equatable/equatable.dart';
import 'ListaUsuarioScreenBloc.dart';

// Eventos
abstract class UsuarioEvent extends Equatable {
  const UsuarioEvent();

  @override
  List<Object> get props => [];
}

class ObtenerUsuarios extends UsuarioEvent {
  final String orden;

  const ObtenerUsuarios(this.orden);

  @override
  List<Object> get props => [orden];
}

// Estados
abstract class UsuarioState extends Equatable {
  const UsuarioState();

  @override
  List<Object> get props => [];
}

class UsuarioInitial extends UsuarioState {}

class UsuarioLoading extends UsuarioState {}

class UsuarioLoaded extends UsuarioState {
  final List<Usuario> usuarios;

  const UsuarioLoaded(this.usuarios);

  @override
  List<Object> get props => [usuarios];
}

class UsuarioError extends UsuarioState {}
